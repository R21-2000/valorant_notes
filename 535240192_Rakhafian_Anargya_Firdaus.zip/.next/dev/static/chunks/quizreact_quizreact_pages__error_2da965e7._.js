(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2d30b_next_dist_compiled_50740b19._.js",
  "static/chunks/2d30b_next_dist_shared_lib_22fdc328._.js",
  "static/chunks/2d30b_next_dist_client_34e5b977._.js",
  "static/chunks/2d30b_next_dist_5530dc95._.js",
  "static/chunks/2d30b_next_error_2bd539d2.js",
  "static/chunks/[next]_entry_page-loader_ts_6347c3f4._.js",
  "static/chunks/2d30b_react-dom_44118fda._.js",
  "static/chunks/2d30b_c3f6f297._.js",
  "static/chunks/[root-of-the-server]__e5ebacac._.js"
],
    source: "entry"
});
