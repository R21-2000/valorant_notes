(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/quizreact/quizreact/node_modules/next/app.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/quizreact/quizreact/node_modules/next/dist/pages/_app.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=2d30b_next_app_c00d8169.js.map