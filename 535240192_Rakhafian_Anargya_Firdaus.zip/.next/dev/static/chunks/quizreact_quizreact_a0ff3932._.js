(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_74a62bff._.js",
  "static/chunks/2d30b_next_dist_compiled_react-dom_516ef63a._.js",
  "static/chunks/2d30b_next_dist_compiled_react-server-dom-turbopack_c2ab5a6c._.js",
  "static/chunks/2d30b_next_dist_compiled_next-devtools_index_9d6ab36e.js",
  "static/chunks/2d30b_next_dist_compiled_19ee7f5b._.js",
  "static/chunks/2d30b_next_dist_client_05aebe55._.js",
  "static/chunks/2d30b_next_dist_9f1750b9._.js",
  "static/chunks/2d30b_@swc_helpers_cjs_ebb28af1._.js"
],
    source: "entry"
});
