__turbopack_load_page_chunks__("/_app", [
  "static/chunks/2d30b_next_dist_compiled_50740b19._.js",
  "static/chunks/2d30b_next_dist_shared_lib_8d7fb627._.js",
  "static/chunks/2d30b_next_dist_client_34e5b977._.js",
  "static/chunks/2d30b_next_dist_12e8bb27._.js",
  "static/chunks/2d30b_next_app_c00d8169.js",
  "static/chunks/[next]_entry_page-loader_ts_3d84d1fa._.js",
  "static/chunks/2d30b_react-dom_44118fda._.js",
  "static/chunks/2d30b_c3f6f297._.js",
  "static/chunks/[root-of-the-server]__cc611d2e._.js",
  "static/chunks/quizreact_quizreact_pages__app_2da965e7._.js",
  "static/chunks/turbopack-quizreact_quizreact_pages__app_e1e5e646._.js"
])
