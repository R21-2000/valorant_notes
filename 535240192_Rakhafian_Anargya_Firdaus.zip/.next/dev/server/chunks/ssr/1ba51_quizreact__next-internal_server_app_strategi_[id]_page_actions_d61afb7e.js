module.exports = [
"[project]/quizreact/quizreact/.next-internal/server/app/strategi/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=1ba51_quizreact__next-internal_server_app_strategi_%5Bid%5D_page_actions_d61afb7e.js.map