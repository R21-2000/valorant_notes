module.exports = [
"[project]/quizreact/quizreact/.next-internal/server/app/strategi/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quizreact_quizreact__next-internal_server_app_strategi_page_actions_7d6f1c8d.js.map