module.exports = [
"[project]/quizreact/quizreact/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quizreact_quizreact__next-internal_server_app__not-found_page_actions_d0a0bc3c.js.map